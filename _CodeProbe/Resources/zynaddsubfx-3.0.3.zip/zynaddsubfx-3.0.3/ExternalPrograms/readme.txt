These are external programs, which can use with ZynAddSubFX or any other midi device. More information is in the documentation (html - webpages).

