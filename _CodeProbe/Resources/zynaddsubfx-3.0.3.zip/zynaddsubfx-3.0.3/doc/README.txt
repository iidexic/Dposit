Requirements for this directory:

 * standalone (latex module)
 * pgfplots (latex module)
 * pst-sigsys (latex module)
 * auto-pst-pdf (latex module)
 * pst-tools (latex module)
 * gnuplot

