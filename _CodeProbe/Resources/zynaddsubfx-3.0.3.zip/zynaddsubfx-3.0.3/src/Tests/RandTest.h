/*
  ZynAddSubFX - a software synthesizer

  RandTest.h - CxxTest for Pseudo-Random Number Generator
  Copyright (C) 2009-2009 Mark McCurry
  Author: Mark McCurry

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
*/

#include "../Misc/Util.h"
#include <cstdlib>
#include <cstdio>
#include <cxxtest/TestSuite.h>
using namespace zyn;

class RandTest:public CxxTest::TestSuite
{
    public:
        void testPRNG(void) {
            //verify RND returns expected pattern when unseeded
            TS_ASSERT_DELTA(RND, 0.607781, 0.00001);
            TS_ASSERT_DELTA(RND, 0.591761, 0.00001);
            TS_ASSERT_DELTA(RND, 0.186133, 0.00001);
            TS_ASSERT_DELTA(RND, 0.286319, 0.00001);
            TS_ASSERT_DELTA(RND, 0.511766, 0.00001);
        }
};
