// This file contains will compile loguru

// https://github.com/emilk/loguru/blob/v1.7.0/loguru.hpp

#define LOGURU_IMPLEMENTATION 1
#include "loguru.hpp"
