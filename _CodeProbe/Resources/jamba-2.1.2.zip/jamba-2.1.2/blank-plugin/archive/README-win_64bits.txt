Install instructions
====================

Windows (64 bit)
----------------
For VST2, copy [-filename-].vst3 and RENAME into [-filename-].dll under
  - C:\ProgramFiles\VstPlugins
  - or any DAW specific path (64bits)
MAKE SURE TO RENAME the file otherwise it will not work

For VST3, copy [-filename-].vst3 under
  - C:\Program Files\Common Files\VST3 (may require admin access)
  - or any DAW specific path (64bits)

