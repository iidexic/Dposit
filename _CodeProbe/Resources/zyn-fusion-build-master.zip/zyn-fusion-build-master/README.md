These are the build scripts used to generate the Zyn-Fusion packages.

These build scripts (and only these build scripts) are licensed under the
WTFPL.

---

## Building on Linux 
See [Building on Linux](../../wiki/Building-on-Linux) on repo's wiki.
