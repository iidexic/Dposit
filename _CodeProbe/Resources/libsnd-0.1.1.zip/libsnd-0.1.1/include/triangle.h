#ifndef TRIANGLE_H_
#define TRIANGLE_H_

/**
 * TODO:
 * - test
 * - write explicit instances into *.cc file
 * - add to header file
 */

namespace snd {

template <class fp_t>
class Triangle {
 public:
  Triangle(fp_t sampleRate) {

  }
  ~Triangle() {}

  fp_t tick() {

  }

 private:
};

}; // !snd

#endif // !TRIANGLE_H_
