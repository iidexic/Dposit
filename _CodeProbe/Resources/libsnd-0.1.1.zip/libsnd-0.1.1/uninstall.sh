#!/usr/bin/env bash

xargs rm -v < build/install_manifest.txt
