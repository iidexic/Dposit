#include <gtest/gtest.h>
#include <snd.h>

// TEST(Bilinear, canGetSampleRate) {

// }
