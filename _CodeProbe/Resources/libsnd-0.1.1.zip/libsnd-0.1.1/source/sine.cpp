#include "sine.h"

namespace snd {

template class Sine<float>;
template class Sine<double>;

}; // !snd
