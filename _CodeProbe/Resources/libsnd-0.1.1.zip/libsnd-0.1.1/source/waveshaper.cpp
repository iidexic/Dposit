#include "waveshaper.h"

namespace snd {

template class WaveShaper<float>;
template class WaveShaper<double>;

}; // !snd
