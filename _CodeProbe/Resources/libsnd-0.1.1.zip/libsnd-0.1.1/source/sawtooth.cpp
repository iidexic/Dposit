#include "sawtooth.h"

namespace snd {

template class Sawtooth<float>;
template class Sawtooth<double>;

}; // !snd
