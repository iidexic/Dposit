#include <kfr/all.hpp>

using namespace kfr;

int main(int argc, char** argv) { return 0; }
