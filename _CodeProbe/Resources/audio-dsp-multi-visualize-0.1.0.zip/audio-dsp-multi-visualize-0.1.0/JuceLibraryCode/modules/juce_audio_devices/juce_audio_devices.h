// This is an auto-generated file to redirect any included
// module headers to the correct external folder.

#include "../../../juce/modules/juce_audio_devices/juce_audio_devices.h"

