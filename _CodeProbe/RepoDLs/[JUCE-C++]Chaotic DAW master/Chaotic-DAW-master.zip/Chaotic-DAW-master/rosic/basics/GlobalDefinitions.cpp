#include "GlobalDefinitions.h"

#ifdef _MSC_VER
  unsigned long long infDoubleAsInteger = 0x7FF0000000000000ULL;
#endif