#include "rosic_RealFunctionEvaluationAlgorithms.h"
using namespace rosic;





