/* Null stubs for coprocessor precision settings */

int
sprec() {return 0; }

int
dprec() {return 0; }

int
ldprec() {return 0; }
