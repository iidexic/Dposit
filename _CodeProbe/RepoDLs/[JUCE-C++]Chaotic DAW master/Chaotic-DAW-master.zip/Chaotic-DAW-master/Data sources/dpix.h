/* (Auto-generated binary data file). */

#ifndef BINARY_DPIX_H
#define BINARY_DPIX_H

namespace dpix
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 7196;

};

#endif
