/* (Auto-generated binary data file). */

#ifndef BINARY_ROXX_H
#define BINARY_ROXX_H

namespace roxx
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 11213;

};

#endif
