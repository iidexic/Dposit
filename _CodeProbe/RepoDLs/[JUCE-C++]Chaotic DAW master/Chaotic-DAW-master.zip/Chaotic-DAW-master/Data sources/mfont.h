/* (Auto-generated binary data file). */

#ifndef BINARY_MFONT_H
#define BINARY_MFONT_H

namespace mfont
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 5361;

};

#endif
