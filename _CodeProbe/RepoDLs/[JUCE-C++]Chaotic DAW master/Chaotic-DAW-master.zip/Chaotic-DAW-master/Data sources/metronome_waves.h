/* (Auto-generated binary data file). */

#ifndef BINARY_METROWAVS_H
#define BINARY_METROWAVS_H

namespace MetroWavs
{
    extern const char*  barwav;
    const int           barwavSize = 14728;

    extern const char*  beatwav;
    const int           beatwavSize = 9264;

};

#endif
