/* (Auto-generated binary data file). */

#ifndef BINARY_PROJS_H
#define BINARY_PROJS_H

namespace projs
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 5179;

};

#endif
