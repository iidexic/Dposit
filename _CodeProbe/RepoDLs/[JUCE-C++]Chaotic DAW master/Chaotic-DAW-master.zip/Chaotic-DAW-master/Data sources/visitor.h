/* (Auto-generated binary data file). */

#ifndef BINARY_VISITOR_H
#define BINARY_VISITOR_H

namespace visitor
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 3284;

};

#endif
