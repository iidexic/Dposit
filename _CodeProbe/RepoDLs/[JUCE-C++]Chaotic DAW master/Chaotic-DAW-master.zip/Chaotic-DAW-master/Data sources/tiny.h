/* (Auto-generated binary data file). */

#ifndef BINARY_TINY_H
#define BINARY_TINY_H

namespace tiny
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 7787;

};

#endif
