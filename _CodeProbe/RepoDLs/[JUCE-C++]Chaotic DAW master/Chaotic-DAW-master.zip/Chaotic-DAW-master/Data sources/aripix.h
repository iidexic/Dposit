/* (Auto-generated binary data file). */

#ifndef BINARY_ARIPIX_H
#define BINARY_ARIPIX_H

namespace aripix
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 9251;

};

#endif
