/* (Auto-generated binary data file). */

#ifndef BINARY_BIG_H
#define BINARY_BIG_H

namespace big
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 10749;

};

#endif
