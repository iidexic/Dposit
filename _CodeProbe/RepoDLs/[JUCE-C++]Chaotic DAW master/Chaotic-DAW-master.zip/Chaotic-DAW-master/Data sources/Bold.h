/* (Auto-generated binary data file). */

#ifndef BINARY_BOLD_H
#define BINARY_BOLD_H

namespace Bold
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 3007;

};

#endif
