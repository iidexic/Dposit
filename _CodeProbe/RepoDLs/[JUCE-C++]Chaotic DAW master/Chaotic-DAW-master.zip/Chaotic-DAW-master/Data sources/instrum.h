/* (Auto-generated binary data file). */

#ifndef BINARY_INSTRUM_H
#define BINARY_INSTRUM_H

namespace instrum
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 5128;

};

#endif
