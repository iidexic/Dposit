/* (Auto-generated binary data file). */

#ifndef BINARY_TAHOMA_H
#define BINARY_TAHOMA_H

namespace tahoma
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 185223;

};

#endif
