/* (Auto-generated binary data file). */

#ifndef BINARY_FIXED_H
#define BINARY_FIXED_H

namespace fixed
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 4937;

};

#endif
