/* (Auto-generated binary data file). */

#ifndef BINARY_TINY1_H
#define BINARY_TINY1_H

namespace tiny1
{
    extern const char*  fontbin_bin;
    const int           fontbin_binSize = 7781;

};

#endif
